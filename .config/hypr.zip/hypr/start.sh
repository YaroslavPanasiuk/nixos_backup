#!/usr/bin/env bash 
swww init &
swww img /home/yaros/Documents/Wallpapers/frieren-sousou-no-frieren-anime-hd-wallpaper-uhdpaper.com-601@1@n.jpg &
nm-applet --indicator &
waybar &
dunst
