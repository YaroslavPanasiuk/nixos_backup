#!/bin/sh
if [[ $(pidof swaybg) ]]; then
  pkill swaybg
fi

swww query || swww-daemon

#change-wallpaper using swww
swww img ~/Documents/Wallpapers/frieren.jpg --transition-fps 60 --transition-type outer --transition-pos 230,1060  --transition-duration 2
/home/yaros/.config/waybar/post_setting.sh

