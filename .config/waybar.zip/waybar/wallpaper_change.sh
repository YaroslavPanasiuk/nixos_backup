#!/bin/sh

DIR=~/Documents/Wallpapers/
PICS=($(ls ${DIR}))

RANDOMPICS=${PICS[ $RANDOM % ${#PICS[@]} ]}

echo $Y
echo $Y_NEW
if [[ $(pidof swaybg) ]]; then
  pkill swaybg
fi

swww query || swww-daemon
swww img ${DIR}/${RANDOMPICS} --transition-fps 60 --transition-type grow --transition-pos 230,1060  --transition-duration 2

/home/yaros/.config/waybar/post_setting.sh
