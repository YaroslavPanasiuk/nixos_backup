#!/bin/sh
query=$(swww query)
path="${query#*/}"
wal -i "/$path"
pkill waybar; waybar
if pidof -qx "rofi"; then
 	pkill rofi
 	rofi -show drun -config ~/.config/wofi/config.rasi
 fi
 cp ~/.cache/wal/dunstrc ~/.config/dunst
 pkill dunst
 /home/yaros/.config/waybar/update_telegram.sh
